<?php


global $_LANG;

$_LANG['ecshop_allpay_atm'] = '<font color=blue>歐付寶 ALLPAY ATM</font>';
$_LANG['ecshop_allpay_atm_desc'] = ' 歐付寶 ALLPAY - <font color=red> ATM</font>';
$_LANG['ecshop_allpay_atm_test_mode'] = '測試模式？';
$_LANG['ecshop_allpay_atm_test_mode_range']['Yes'] = '是';
$_LANG['ecshop_allpay_atm_test_mode_range']['No'] = '否';
$_LANG['ecshop_allpay_atm_account'] = '商店代號(必填)';
$_LANG['ecshop_allpay_atm_iv'] = '歐付寶 ALLPAY IV(必填)';
$_LANG['ecshop_allpay_atm_key'] = '歐付寶 ALLPAY KEY(必填)';

$_LANG['pay_button'] = '歐付寶 ALLPAY ATM付款';

$_LANG['text_goods'] = '網路商品一批';
$_LANG['text_currency'] = '元';
$_LANG['text_paying'] = '<b>付款中</b> %s\n付款方式: %s\n付款時間: %s\n銀行代碼: %s\n虛擬帳號: %s\n付款截止日: %s\n';
$_LANG['text_paid'] = '付款完成';
